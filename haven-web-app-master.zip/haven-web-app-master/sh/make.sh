#!/usr/bin/env bash



export HAVEN_DESKTOP_DEVELOPMENT=false
export NODE_INSTALLER=npm

npm run make --prefix haven-desktop-app


