import styled from "styled-components";

export const Body = styled.div`
  margin: 10px;
`;

export const Wrapper = styled.div`
  height: 100%;
`;
