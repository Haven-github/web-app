import React, { Component } from "react";
import { Assets } from "../../../../../shared/pages/_wallet/assets";

export class AssetsDesktop extends Component {
  render() {
    return <Assets />;
  }
}
