


export const STORE_VAULT_AT_DISKED = "store_vault_at_disk";