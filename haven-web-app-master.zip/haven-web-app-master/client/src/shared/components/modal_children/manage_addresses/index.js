// Library Imports
import React from "react";

// Relative Imports

const ManageAddresses = ({ children }) => {
  return <>{children}</>;
};

export default ManageAddresses;
