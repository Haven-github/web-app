import styled from "styled-components";

export const Progress = styled.progress`
  margin-top: 20px;
`;

export const Container = styled.div`
  background: none;
`;
