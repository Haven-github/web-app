import styled from "styled-components";

export const Container = styled.div`
  grid-column: 1 / 3;
  margin-top: -20px;
`;
